#define _CRT_SECURE_NO_WARNINGS
#include "Gra.h"


Gra gra;

int main()
{
	gra.menu();
	return 0;
}


